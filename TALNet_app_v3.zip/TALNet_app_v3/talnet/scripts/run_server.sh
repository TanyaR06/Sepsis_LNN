#!/usr/bin/env bash
# Launch the TA-LNN dashboard + API on http://localhost:8000
set -e
cd "$(dirname "$0")/.."
export PYTHONWARNINGS=ignore
exec uvicorn backend.app:app --host 0.0.0.0 --port "${PORT:-8000}"
