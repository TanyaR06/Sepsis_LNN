#!/usr/bin/env bash
# Retrain TA-LNN on a PhysioNet/CinC 2019 training folder of .psv files.
#   DATA=/path/to/training_setA ./scripts/train.sh
set -e
cd "$(dirname "$0")/.."
export PYTHONWARNINGS=ignore
DATA="${DATA:?set DATA=/path/to/training_setA}"
python -m backend.train \
  --data "$DATA" \
  --n-train "${N_TRAIN:-1000}" \
  --n-cal   "${N_CAL:-400}" \
  --n-test  "${N_TEST:-700}" \
  --epochs  "${EPOCHS:-22}" \
  --batch-size "${BATCH:-64}" \
  --pos-weight "${POS_WEIGHT:-8}" \
  --target-far "${TARGET_FAR:-0.10}" \
  --procs "${PROCS:-2}"
