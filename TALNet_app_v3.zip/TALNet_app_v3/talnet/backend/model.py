"""
Topology-Aware Liquid Neural Network (TA-LNN / TALNet) forward model.

Faithful to the paper's equations (Section III-C):

  tau_o   = softplus(W_tau . [u_o, phi_o, h_o]) + tau_base            (Eq.4)
  f_o     = tanh(W_f . [u_o, phi_o, h_o])
  h_o     = (h_o + dt * f_o / tau_o) / (1 + dt / tau_o)               (Eq.5)
  h_tilde = h + lambda * tanh(W_c . concat(h_1..h_K))                 (Eq.6)
  r_t     = sigmoid(W_r . [h_tilde ; e_demog])                        (Eq.7)
  a_t     = [ g(h_tilde_1), ..., g(h_tilde_K) ]  (softmax)            (Eq.8)

Implemented with ``autograd.numpy`` so a single implementation is used for both
training (reverse-mode autodiff) and plain-NumPy inference.  Each organ has its
own liquid unit with a physiologically-motivated base time constant tau_base.
"""
import autograd.numpy as anp
import numpy as np

from .config import (
    ORGANS, K_ORGANS, ORGAN_CHANNELS, ORGAN_TAU_BASE, HIDDEN_PER_ORGAN,
    COUPLING_LAMBDA, TOPO_FEATS, DEMOG_FEATURES,
)

H = HIDDEN_PER_ORGAN
N_DEMOG = len(DEMOG_FEATURES)


def _softplus(x):
    return anp.log1p(anp.exp(-anp.abs(x))) + anp.maximum(x, 0.0)


def _sigmoid(x):
    return 1.0 / (1.0 + anp.exp(-x))


def organ_input_dim(o):
    return 3 * len(ORGAN_CHANNELS[o]) + TOPO_FEATS + H


# ---------------------------------------------------------------------------
# Parameter initialization / (de)serialization
# ---------------------------------------------------------------------------
def init_params(seed=0):
    rng = np.random.RandomState(seed)

    def rand(shape, scale):
        return rng.randn(*shape) * scale

    p = {}
    for o in ORGANS:
        d = organ_input_dim(o)
        s = 1.0 / np.sqrt(d)
        p[f"Wtau_{o}"] = rand((H, d), s)
        p[f"btau_{o}"] = np.zeros(H)
        p[f"Wf_{o}"] = rand((H, d), s)
        p[f"bf_{o}"] = np.zeros(H)
        p[f"Wg_{o}"] = rand((1, H), 1.0 / np.sqrt(H))
        p[f"bg_{o}"] = np.zeros(1)
    KH = K_ORGANS * H
    p["Wc"] = rand((KH, KH), 1.0 / np.sqrt(KH))
    p["bc"] = np.zeros(KH)
    p["Wr"] = rand((1, KH + N_DEMOG), 1.0 / np.sqrt(KH + N_DEMOG))
    p["br"] = np.zeros(1)
    return p


def count_params(p):
    return int(sum(np.asarray(v).size for v in p.values()))


def save_params(p, path):
    np.savez(path, **{k: np.asarray(v) for k, v in p.items()})


def load_params(path):
    z = np.load(path)
    return {k: z[k] for k in z.files}


TAU_BASE = np.array([ORGAN_TAU_BASE[o] for o in ORGANS])  # (K,)


# ---------------------------------------------------------------------------
# Forward pass (batched over B patients, padded to T)
# ---------------------------------------------------------------------------
def forward(params, batch):
    """
    batch keys (all NumPy arrays, padded):
      U[o]   : (B, T, 3*c_o)
      PHI[o] : (B, T, 7)
      demog  : (B, N_DEMOG)
      dt     : scalar hourly step (default 1.0)
    Returns:
      risk    : (B, T)             per-hour deterioration probability r_t
      cascade : (B, T, K)          organ attribution a_t (rows sum to 1)
      tau_mean: (B, T, K)          mean effective time constant per organ (diag)
    """
    U = batch["U"]; PHI = batch["PHI"]; demog = batch["demog"]
    dt = batch.get("dt", 1.0)
    o0 = ORGANS[0]
    B, T = U[o0].shape[0], U[o0].shape[1]

    h = {o: anp.zeros((B, H)) for o in ORGANS}
    risk_steps, casc_steps, tau_steps = [], [], []

    for t in range(T):
        tau_t = []
        for oi, o in enumerate(ORGANS):
            inp = anp.concatenate([U[o][:, t, :], PHI[o][:, t, :], h[o]], axis=1)  # (B,d)
            tau = _softplus(inp @ params[f"Wtau_{o}"].T + params[f"btau_{o}"]) + TAU_BASE[oi]
            fcand = anp.tanh(inp @ params[f"Wf_{o}"].T + params[f"bf_{o}"])
            h[o] = (h[o] + dt * fcand / tau) / (1.0 + dt / tau)
            tau_t.append(anp.mean(tau, axis=1, keepdims=True))       # (B,1)
        tau_steps.append(anp.concatenate(tau_t, axis=1))             # (B,K)

        # ---- coupling (Eq.6) ----
        h_cat = anp.concatenate([h[o] for o in ORGANS], axis=1)      # (B, K*H)
        h_tilde_cat = h_cat + COUPLING_LAMBDA * anp.tanh(h_cat @ params["Wc"].T + params["bc"])
        h_tilde = {o: h_tilde_cat[:, oi * H:(oi + 1) * H] for oi, o in enumerate(ORGANS)}

        # ---- risk head (Eq.7) ----
        r_in = anp.concatenate([h_tilde_cat, demog], axis=1)
        r = _sigmoid(r_in @ params["Wr"].T + params["br"])[:, 0]     # (B,)
        risk_steps.append(r)

        # ---- cascade head (Eq.8), softmax over organs ----
        scores = anp.concatenate(
            [h_tilde[o] @ params[f"Wg_{o}"].T + params[f"bg_{o}"] for o in ORGANS], axis=1
        )                                                            # (B,K)
        scores = scores - anp.max(scores, axis=1, keepdims=True)
        ez = anp.exp(scores)
        casc = ez / (anp.sum(ez, axis=1, keepdims=True) + 1e-9)
        casc_steps.append(casc)

    risk = anp.stack(risk_steps, axis=1)                             # (B,T)
    cascade = anp.stack(casc_steps, axis=1)                          # (B,T,K)
    tau_mean = anp.stack(tau_steps, axis=1)                          # (B,T,K)
    return risk, cascade, tau_mean
