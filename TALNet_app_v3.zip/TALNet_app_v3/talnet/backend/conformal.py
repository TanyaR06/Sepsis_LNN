"""
Split-conformal calibration of the alarm (paper Section III-D).

On a held-out calibration split we compute, for each positive-labelled hour, the
nonconformity score s = 1 - r (a confident true event is *conforming*, so its
score is small).  The empirical (1 - alpha) quantile of these scores, with the
finite-sample correction ceil((n+1)(1-alpha))/n, fixes a threshold that the
alarm must respect:

    theta = 1 - quantile_{1-alpha}( s )

Firing when r >= theta then covers a guaranteed (1 - alpha) fraction of true
deterioration hours.  We also retain the calibration risk distributions so that
each live prediction can be turned into a calibrated confidence and a
false-alarm p-value.
"""
import json
import numpy as np


class ConformalAlarm:
    def __init__(self, theta, alpha, pos_risks, neg_risks, coverage,
                 theta_conformal=None, far_target=None, far_empirical=None, sensitivity=None):
        self.theta = float(theta)                     # operating alarm threshold
        self.alpha = float(alpha)
        self.pos_risks = np.sort(np.asarray(pos_risks, float))
        self.neg_risks = np.sort(np.asarray(neg_risks, float))
        self.coverage = float(coverage)               # conformal coverage guarantee (empirical)
        self.theta_conformal = float(theta_conformal) if theta_conformal is not None else self.theta
        self.far_target = far_target
        self.far_empirical = far_empirical
        self.sensitivity = sensitivity

    # -- construction --------------------------------------------------------
    @classmethod
    def calibrate(cls, risks, labels, alpha=0.10, patients=None, target_far=0.10):
        """Split-conformal coverage guarantee (paper Section III-D) *plus* a
        patient-level operating threshold chosen at a target false-alarm rate
        (the paper reports lead time at a fixed FAR).

        risks/labels : flattened hourly arrays (for the conformal quantile).
        patients     : optional list of {"y","risk"} for the FAR sweep; if
                       omitted the operating threshold falls back to the
                       conformal one.
        """
        risks = np.asarray(risks, float); labels = np.asarray(labels, float)
        pos = risks[labels > 0.5]; neg = risks[labels <= 0.5]
        if pos.size == 0:
            return cls(0.5, alpha, np.array([0.5]), neg, 0.0)

        # conformal coverage-guarantee threshold
        scores = 1.0 - pos
        n = scores.size
        k = min(max(int(np.ceil((n + 1) * (1 - alpha))), 1), n)
        q = np.sort(scores)[k - 1]
        theta_conf = 1.0 - q
        coverage = float(np.mean(pos >= theta_conf))

        # patient-level FAR-controlled operating threshold
        theta_op = theta_conf; far_emp = None; sens = None
        if patients is not None:
            nonsep = [np.asarray(p["risk"]) for p in patients if np.asarray(p["y"]).max() < 0.5]
            if nonsep:
                grid = np.unique(np.concatenate([np.linspace(0, 1, 201), neg]))
                best = 1.0
                for th in np.sort(grid):
                    far = np.mean([(r >= th).any() for r in nonsep])
                    if far <= target_far:
                        best = th; break
                theta_op = float(best)
                far_emp = float(np.mean([(r >= theta_op).any() for r in nonsep]))
            sens = float(np.mean(pos >= theta_op))
        return cls(theta_op, alpha, pos, neg, coverage,
                   theta_conformal=theta_conf, far_target=target_far,
                   far_empirical=far_emp, sensitivity=sens)

    # -- use -----------------------------------------------------------------
    def alarm(self, risk):
        return np.asarray(risk) >= self.theta

    def confidence(self, risk):
        """Calibrated confidence that a firing risk reflects a true event:
        ECDF of risk within the positive calibration distribution."""
        r = np.asarray(risk, float)
        return np.searchsorted(self.pos_risks, r, side="right") / max(len(self.pos_risks), 1)

    def false_alarm_pvalue(self, risk):
        """Conformal p-value under the non-septic (negative) distribution:
        fraction of calibration negatives with risk >= r (small => trustworthy)."""
        r = np.asarray(risk, float)
        n = len(self.neg_risks)
        ge = n - np.searchsorted(self.neg_risks, r, side="left")
        return (ge + 1) / (n + 1)

    # -- io ------------------------------------------------------------------
    def to_dict(self):
        return {
            "theta": self.theta, "alpha": self.alpha,
            "coverage": self.coverage,
            "target_coverage": 1 - self.alpha,
            "theta_conformal": self.theta_conformal,
            "far_target": self.far_target,
            "far_empirical": self.far_empirical,
            "sensitivity": self.sensitivity,
            "pos_risks": self.pos_risks.tolist(),
            "neg_risks": self.neg_risks.tolist(),
        }

    def save(self, path):
        with open(path, "w") as fh:
            json.dump(self.to_dict(), fh)

    @classmethod
    def from_dict(cls, d):
        return cls(d["theta"], d["alpha"], d["pos_risks"], d["neg_risks"], d["coverage"],
                   theta_conformal=d.get("theta_conformal"), far_target=d.get("far_target"),
                   far_empirical=d.get("far_empirical"), sensitivity=d.get("sensitivity"))

    @classmethod
    def load(cls, path):
        with open(path) as fh:
            return cls.from_dict(json.load(fh))
