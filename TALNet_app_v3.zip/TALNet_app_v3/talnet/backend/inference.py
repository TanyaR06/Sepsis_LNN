"""
End-to-end inference for a single ICU record (paper Table 1, steps 8-17).

Loads the trained artifacts (weights, scaler, conformal calibrator) and returns
the per-hour risk trajectory, calibrated alarm, organ-cascade attribution,
effective time constants, and a clinical summary (lead time, confidence, etc.).
"""
import os
import json
import numpy as np

from .config import ORGANS, ORGAN_LABELS, K_ORGANS, CONFORMAL_ALPHA, ORGAN_TAU_BASE
from .data import build_patient, Scaler, read_psv, read_records_json
from .model import forward, load_params, count_params
from .conformal import ConformalAlarm

MODELS_DIR = os.environ.get(
    "TALNET_MODELS_DIR",
    os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models"),
)


class TALNet:
    """Loaded, ready-to-serve TA-LNN model."""

    def __init__(self, models_dir=MODELS_DIR):
        self.dir = models_dir
        self.params = load_params(os.path.join(models_dir, "talnet_weights.npz"))
        with open(os.path.join(models_dir, "scaler.json")) as fh:
            self.scaler = Scaler.from_dict(json.load(fh))
        self.conformal = ConformalAlarm.load(os.path.join(models_dir, "conformal.json"))
        meta_path = os.path.join(models_dir, "meta.json")
        self.meta = json.load(open(meta_path)) if os.path.exists(meta_path) else {}
        self.n_params = count_params(self.params)

    # -- batch helper: single patient -> padded batch of size 1 --------------
    def _single_batch(self, feats):
        U = {o: feats["U"][o][None, ...] for o in ORGANS}
        PHI = {o: feats["PHI"][o][None, ...] for o in ORGANS}
        demog = feats["demog"][None, :]
        return {"U": U, "PHI": PHI, "demog": demog, "dt": 1.0}

    # -- core predict --------------------------------------------------------
    def predict(self, vals, demog, label=None):
        feats = build_patient(vals, demog, label, self.scaler)
        risk, cascade, tau = forward(self.params, self._single_batch(feats))
        risk = np.asarray(risk)[0]                     # (T,)
        cascade = np.asarray(cascade)[0]               # (T,K)
        tau = np.asarray(tau)[0]                        # (T,K)
        T = len(risk)

        theta = self.conformal.theta
        alarm = risk >= theta
        first_alarm = int(np.argmax(alarm)) if alarm.any() else None

        y = feats["y"]
        onset = None
        lead_time = None
        if y is not None and np.asarray(y).max() > 0.5:
            onset = int(np.argmax(np.asarray(y) > 0.5))
            if first_alarm is not None and first_alarm <= onset:
                lead_time = onset - first_alarm

        peak_idx = int(np.argmax(risk))
        confidence = float(self.conformal.confidence(risk[peak_idx]))
        fa_p = float(self.conformal.false_alarm_pvalue(risk[peak_idx]))

        # organ attribution at the decisive hour (first alarm else peak risk)
        decis = first_alarm if first_alarm is not None else peak_idx
        attribution = {ORGANS[k]: float(cascade[decis, k]) for k in range(K_ORGANS)}
        driver = max(attribution, key=attribution.get)

        return {
            "n_hours": T,
            "hours": list(range(1, T + 1)),
            "risk": [float(x) for x in risk],
            "alarm": [bool(x) for x in alarm],
            "threshold": float(theta),
            "cascade": [[float(cascade[t, k]) for k in range(K_ORGANS)] for t in range(T)],
            "tau": [[float(tau[t, k]) for k in range(K_ORGANS)] for t in range(T)],
            "organs": ORGANS,
            "organ_labels": [ORGAN_LABELS[o] for o in ORGANS],
            "label": ([int(v) for v in np.asarray(y)] if y is not None else None),
            "onset_hour": (onset + 1 if onset is not None else None),
            "first_alarm_hour": (first_alarm + 1 if first_alarm is not None else None),
            "lead_time_hours": lead_time,
            "peak_risk": float(risk[peak_idx]),
            "peak_hour": peak_idx + 1,
            "confidence": confidence,
            "coverage_level": 1 - CONFORMAL_ALPHA,
            "false_alarm_pvalue": fa_p,
            "attribution": attribution,
            "primary_driver": driver,
            "primary_driver_label": ORGAN_LABELS[driver],
        }

    def predict_psv(self, path):
        vals, demog, label = read_psv(path)
        return self.predict(vals, demog, label)

    def predict_json(self, record):
        vals, demog, label = read_records_json(record)
        return self.predict(vals, demog, label)


_MODEL = None


def get_model():
    global _MODEL
    if _MODEL is None:
        _MODEL = TALNet()
    return _MODEL
