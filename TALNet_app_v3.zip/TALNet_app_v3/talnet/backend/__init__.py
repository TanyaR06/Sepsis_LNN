"""TA-LNN / TALNet — Topology-Aware Liquid Neural Network for sepsis early warning."""
__version__ = "1.0.0"
