"""
Global configuration for the Topology-Aware Liquid Neural Network (TA-LNN / TALNet).

Everything here is derived directly from the paper:
  "Topology-Aware Liquid Neural Networks for Early Prediction of Sepsis-Induced
   Multi-Organ Failure from Irregularly Sampled ICU Streams."

The PhysioNet/CinC 2019 record layout (8 vitals + 26 labs + 6 demographic/admin
columns + 1 hourly SepsisLabel) is fixed by the challenge and reproduced here.
"""

# ---------------------------------------------------------------------------
# PhysioNet 2019 column layout (order matters — matches the .psv header exactly)
# ---------------------------------------------------------------------------
VITALS = ["HR", "O2Sat", "Temp", "SBP", "MAP", "DBP", "Resp", "EtCO2"]

LABS = [
    "BaseExcess", "HCO3", "FiO2", "pH", "PaCO2", "SaO2", "AST", "BUN",
    "Alkalinephos", "Calcium", "Chloride", "Creatinine", "Bilirubin_direct",
    "Glucose", "Lactate", "Magnesium", "Phosphate", "Potassium",
    "Bilirubin_total", "TroponinI", "Hct", "Hgb", "PTT", "WBC",
    "Fibrinogen", "Platelets",
]

CLINICAL_CHANNELS = VITALS + LABS                      # 34 channels
DEMOG_COLUMNS = ["Age", "Gender", "Unit1", "Unit2", "HospAdmTime", "ICULOS"]
LABEL_COLUMN = "SepsisLabel"
ALL_COLUMNS = CLINICAL_CHANNELS + DEMOG_COLUMNS + [LABEL_COLUMN]  # 41

# Demographic features fed to the risk head (e_demog). Unit1/Unit2 are mostly
# missing in Set A, so we use the four reliably-present admission descriptors.
DEMOG_FEATURES = ["Age", "Gender", "HospAdmTime", "ICULOS"]

# ---------------------------------------------------------------------------
# Per-organ partition of the 34 clinical channels (paper Section III-B).
# Six subsystems: respiratory, cardiovascular, renal, hepatic, coagulation,
# metabolic — grouped by physiological meaning.
# ---------------------------------------------------------------------------
ORGAN_CHANNELS = {
    "respiratory":    ["O2Sat", "Resp", "EtCO2", "FiO2", "pH", "PaCO2", "SaO2", "HCO3", "BaseExcess"],
    "cardiovascular": ["HR", "SBP", "MAP", "DBP", "TroponinI"],
    "renal":          ["BUN", "Creatinine", "Potassium", "Chloride", "Calcium", "Magnesium", "Phosphate"],
    "hepatic":        ["AST", "Bilirubin_direct", "Bilirubin_total", "Alkalinephos"],
    "coagulation":    ["Platelets", "PTT", "Fibrinogen", "Hct", "Hgb", "WBC"],
    "metabolic":      ["Temp", "Glucose", "Lactate"],
}
ORGANS = list(ORGAN_CHANNELS.keys())
K_ORGANS = len(ORGANS)

# Per-organ base time constant tau_base (hours), paper Eq.(4): "some units have
# tau_base close to 1 hour (circulatory) while others are on the order of days
# (renal / hepatic)."  Values chosen within a physiological range per subsystem.
ORGAN_TAU_BASE = {
    "respiratory":    2.0,
    "cardiovascular": 1.0,
    "renal":          36.0,
    "hepatic":        48.0,
    "coagulation":    18.0,
    "metabolic":      6.0,
}

# Human-readable descriptions used by the dashboard.
ORGAN_LABELS = {
    "respiratory":    "Respiratory",
    "cardiovascular": "Cardiovascular",
    "renal":          "Renal",
    "hepatic":        "Hepatic",
    "coagulation":    "Coagulation",
    "metabolic":      "Metabolic",
}

# ---------------------------------------------------------------------------
# Model / pipeline hyper-parameters
# ---------------------------------------------------------------------------
TOPO_WINDOW = 8          # W: sliding window length (hours) for the point cloud
TOPO_FEATS = 7           # phi_o dimensionality: [SumL0,maxL0,n0,SumL1,maxL1,n1,H]
HIDDEN_PER_ORGAN = 16    # H: hidden state width of each organ's liquid unit
COUPLING_LAMBDA = 0.5    # lambda mixing coefficient, paper Eq.(6)
CONFORMAL_ALPHA = 0.10   # 1-alpha = 90% coverage target (paper: 90% level)
CASCADE_WEIGHT = 0.3     # weak-supervision weight for the organ-cascade head

# Column index helpers
CH_INDEX = {c: i for i, c in enumerate(CLINICAL_CHANNELS)}
ORGAN_CH_IDX = {o: [CH_INDEX[c] for c in chs] for o, chs in ORGAN_CHANNELS.items()}
