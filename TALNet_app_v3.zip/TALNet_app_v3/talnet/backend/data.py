"""
PhysioNet/CinC 2019 data handling for TA-LNN (paper Section III-A, IV-B).

Implements the paper's data representation *without imputation*:

    u_t = [ x_t (+) m_t ,  m_t ,  Delta_t ]                 (Eq.1)

where x_t is the standardized value vector, m_t the binary observed-mask, and
Delta_t the per-channel gap (hours since that channel was last seen).  Missing
entries are never replaced by estimates; the mask and gap carry the irregularity
into the network intact.

Standardization statistics are computed from *observed values only* (Eq. IV-B).

For the topological descriptor a point cloud is built from a forward-filled copy
of the window (a feature-side operation); the model's input stream keeps its
genuine mask/gap and is never imputed.
"""
import os
import glob
import numpy as np

from .config import (
    CLINICAL_CHANNELS, DEMOG_COLUMNS, DEMOG_FEATURES, LABEL_COLUMN, ALL_COLUMNS,
    ORGANS, ORGAN_CH_IDX, ORGAN_CHANNELS, CH_INDEX, TOPO_WINDOW, TOPO_FEATS,
)
from .topology import persistence_descriptor

N_CH = len(CLINICAL_CHANNELS)


# ---------------------------------------------------------------------------
# Raw .psv reading
# ---------------------------------------------------------------------------
def read_psv(path):
    """Read a PhysioNet .psv file -> (values[T,34], demog[T,6], label[T])."""
    with open(path) as fh:
        header = fh.readline().strip().split("|")
        rows = [ln.strip().split("|") for ln in fh if ln.strip()]
    idx = {c: i for i, c in enumerate(header)}
    arr = np.array(
        [[np.nan if v in ("NaN", "") else float(v) for v in r] for r in rows],
        dtype=np.float64,
    )
    if arr.size == 0:
        arr = np.zeros((0, len(header)))
    vals = np.stack([arr[:, idx[c]] for c in CLINICAL_CHANNELS], axis=1)
    demog = np.stack([arr[:, idx[c]] for c in DEMOG_COLUMNS], axis=1)
    label = arr[:, idx[LABEL_COLUMN]] if LABEL_COLUMN in idx else np.zeros(len(arr))
    return vals, demog, label


def read_records_json(record):
    """Read a patient supplied as JSON (API input).

    ``record`` = {"columns": [...], "data": [[...], ...]}  or
                 {"channels": {"HR": [...], ...}, "n_hours": T}
    Returns (values[T,34], demog[T,6], label[T] or None).
    """
    if "columns" in record and "data" in record:
        cols = record["columns"]
        idx = {c: i for i, c in enumerate(cols)}
        data = np.array(
            [[np.nan if (v is None) else float(v) for v in row] for row in record["data"]],
            dtype=np.float64,
        )

        def col(name):
            if name in idx:
                return data[:, idx[name]]
            return np.full(len(data), np.nan)

        vals = np.stack([col(c) for c in CLINICAL_CHANNELS], axis=1)
        demog = np.stack([col(c) for c in DEMOG_COLUMNS], axis=1)
        label = col(LABEL_COLUMN) if LABEL_COLUMN in idx else None
        return vals, demog, label
    raise ValueError("Unrecognized record JSON schema")


# ---------------------------------------------------------------------------
# Standardization scaler (observed values only)
# ---------------------------------------------------------------------------
class Scaler:
    def __init__(self, mean, std, demog_mean, demog_std):
        self.mean = np.asarray(mean, float)
        self.std = np.asarray(std, float)
        self.demog_mean = np.asarray(demog_mean, float)
        self.demog_std = np.asarray(demog_std, float)

    @classmethod
    def fit(cls, files, max_files=None):
        if max_files:
            files = files[:max_files]
        sums = np.zeros(N_CH); sqs = np.zeros(N_CH); cnt = np.zeros(N_CH)
        dsum = np.zeros(len(DEMOG_COLUMNS)); dsq = np.zeros(len(DEMOG_COLUMNS)); dcnt = np.zeros(len(DEMOG_COLUMNS))
        for f in files:
            v, d, _ = read_psv(f)
            ok = np.isfinite(v)
            sums += np.where(ok, v, 0).sum(0)
            sqs += np.where(ok, v * v, 0).sum(0)
            cnt += ok.sum(0)
            dok = np.isfinite(d)
            dsum += np.where(dok, d, 0).sum(0)
            dsq += np.where(dok, d * d, 0).sum(0)
            dcnt += dok.sum(0)
        cnt = np.maximum(cnt, 1); dcnt = np.maximum(dcnt, 1)
        mean = sums / cnt
        std = np.sqrt(np.maximum(sqs / cnt - mean ** 2, 1e-6))
        dmean = dsum / dcnt
        dstd = np.sqrt(np.maximum(dsq / dcnt - dmean ** 2, 1e-6))
        return cls(mean, std, dmean, dstd)

    def to_dict(self):
        return {
            "channels": CLINICAL_CHANNELS,
            "mean": self.mean.tolist(), "std": self.std.tolist(),
            "demog_columns": DEMOG_COLUMNS,
            "demog_mean": self.demog_mean.tolist(), "demog_std": self.demog_std.tolist(),
        }

    @classmethod
    def from_dict(cls, d):
        return cls(d["mean"], d["std"], d["demog_mean"], d["demog_std"])


# ---------------------------------------------------------------------------
# Feature construction for one patient
# ---------------------------------------------------------------------------
def _forward_fill(col):
    """Forward-fill a 1-D array of values with NaNs; leading NaNs -> 0."""
    out = np.zeros_like(col)
    last = 0.0
    for i, v in enumerate(col):
        if np.isfinite(v):
            last = v
        out[i] = last
    return out


def build_patient(vals, demog, label, scaler, window=TOPO_WINDOW):
    """Return the full per-hour feature bundle for one patient.

    Keys:
      U[o]   : (T, 3*c_o)  organ input stream [x*m, m, gap]
      PHI[o] : (T, 7)      per-organ topological descriptor phi_o(t)
      demog  : (4,)        standardized e_demog
      y      : (T,)        hourly sepsis label (or None)
      organ_target : (T,K) soft organ-derangement distribution (weak cascade sup.)
      T      : int
    """
    T = vals.shape[0]
    mask = np.isfinite(vals).astype(np.float64)                    # m_t
    x_std = np.where(mask > 0, (vals - scaler.mean) / scaler.std, 0.0)

    # per-channel gap Delta_t (hours since last observed), log-compressed
    gap = np.zeros((T, N_CH))
    since = np.zeros(N_CH)
    for t in range(T):
        gap[t] = since
        since = np.where(mask[t] > 0, 0.0, since + 1.0)
    gap_feat = np.log1p(gap)

    # forward-filled standardized values (for point clouds + derangement)
    ff = np.zeros((T, N_CH))
    for c in range(N_CH):
        col = np.where(mask[:, c] > 0, x_std[:, c], np.nan)
        ff[:, c] = _forward_fill(col)

    # ---- per-organ input stream U and topology PHI ----
    U, PHI = {}, {}
    for o in ORGANS:
        cols = ORGAN_CH_IDX[o]
        xo = x_std[:, cols] * mask[:, cols]
        mo = mask[:, cols]
        go = gap_feat[:, cols]
        U[o] = np.concatenate([xo, mo, go], axis=1)               # (T, 3*c_o)

        phi = np.zeros((T, TOPO_FEATS))
        ffo = ff[:, cols]
        for t in range(T):
            lo = max(0, t - window + 1)
            phi[t] = persistence_descriptor(ffo[lo:t + 1])
        PHI[o] = phi

    # ---- demographics e_demog ----
    dvec = []
    dmap = {c: i for i, c in enumerate(DEMOG_COLUMNS)}
    last_demog = np.where(np.isfinite(demog[-1]), demog[-1], np.nan) if T else np.zeros(len(DEMOG_COLUMNS))
    for name in DEMOG_FEATURES:
        i = dmap[name]
        col = demog[:, i]
        val = col[np.isfinite(col)]
        v = val[-1] if val.size else scaler.demog_mean[i]
        dvec.append((v - scaler.demog_mean[i]) / scaler.demog_std[i])
    demog_vec = np.array(dvec, dtype=np.float64)

    # ---- soft organ-derangement target (weak supervision for cascade head) ----
    organ_target = np.zeros((T, len(ORGANS)))
    for oi, o in enumerate(ORGANS):
        cols = ORGAN_CH_IDX[o]
        organ_target[:, oi] = np.abs(ff[:, cols]).mean(axis=1)
    # temperature-softmax across organs -> distribution
    z = organ_target - organ_target.max(axis=1, keepdims=True)
    ez = np.exp(z)
    organ_target = ez / (ez.sum(axis=1, keepdims=True) + 1e-9)

    return {
        "U": U, "PHI": PHI, "demog": demog_vec,
        "y": (label.astype(np.float64) if label is not None else None),
        "organ_target": organ_target, "T": T,
    }


# ---------------------------------------------------------------------------
# Dataset helpers
# ---------------------------------------------------------------------------
def list_psv(folder):
    return sorted(glob.glob(os.path.join(folder, "*.psv")))
