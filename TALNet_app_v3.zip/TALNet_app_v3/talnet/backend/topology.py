"""
Per-organ topological description via persistent homology (paper Section III-B).

For an organ ``o`` at time ``t`` the most recent ``W`` hours of that organ's
channels form a point cloud C_o(t) (Eq.2).  We compute the persistence diagram
D_o(t) over the Vietoris-Rips filtration and condense it into the fixed-length
descriptor phi_o(t) (Eq.3):

    phi_o(t) = [ sum L0, max L0, n0, sum L1, max L1, n1, H(l) ]

where L0/L1 are the lifetimes of connected components (H0) and loops (H1),
n0/n1 their counts, and H the Shannon entropy of the normalized lifetimes.

Exact H0+H1 persistence is computed with ``ripser`` (Tralie et al., ref [15]).
If ``ripser`` is unavailable we fall back to an exact H0 descriptor computed from
the Euclidean minimum spanning tree (identical H0 persistence) with H1 set to 0,
so the pipeline never hard-fails on a bare install.
"""
import warnings
import numpy as np

warnings.filterwarnings("ignore", module="ripser")

try:
    from ripser import ripser
    _HAVE_RIPSER = True
except Exception:                                    # pragma: no cover
    _HAVE_RIPSER = False

from .config import TOPO_FEATS

_INF = np.inf


def have_ripser() -> bool:
    return _HAVE_RIPSER


# ---------------------------------------------------------------------------
# H0 via Euclidean MST (exact, dependency-free fallback)
# ---------------------------------------------------------------------------
def _h0_lifetimes_mst(pts: np.ndarray) -> np.ndarray:
    """Finite H0 lifetimes = sorted edge weights of the Euclidean MST.

    In the Rips filtration every point is born at scale 0; components merge at
    the MST edge lengths, so the finite H0 bars are exactly the MST weights.
    """
    n = pts.shape[0]
    if n < 2:
        return np.zeros(0)
    # Prim's algorithm on the dense distance matrix.
    d = np.sqrt(((pts[:, None, :] - pts[None, :, :]) ** 2).sum(-1))
    in_tree = np.zeros(n, dtype=bool)
    in_tree[0] = True
    best = d[0].copy()
    best[0] = _INF
    weights = []
    for _ in range(n - 1):
        j = int(np.argmin(best))
        weights.append(best[j])
        in_tree[j] = True
        best = np.minimum(best, d[j])
        best[in_tree] = _INF
    return np.sort(np.asarray(weights))


def _entropy(lifetimes: np.ndarray) -> float:
    lifetimes = lifetimes[np.isfinite(lifetimes) & (lifetimes > 0)]
    if lifetimes.size == 0:
        return 0.0
    p = lifetimes / lifetimes.sum()
    return float(-(p * np.log(p + 1e-12)).sum())


def _summarize(l0: np.ndarray, l1: np.ndarray) -> np.ndarray:
    l0 = l0[np.isfinite(l0)]
    l1 = l1[np.isfinite(l1)]
    all_life = np.concatenate([l0, l1]) if (l0.size + l1.size) else np.zeros(0)
    return np.array([
        float(l0.sum()),                       # sum of H0 lifetimes
        float(l0.max()) if l0.size else 0.0,   # max H0 lifetime
        float(l0.size),                        # number of H0 features
        float(l1.sum()),                       # sum of H1 lifetimes
        float(l1.max()) if l1.size else 0.0,   # max H1 lifetime
        float(l1.size),                        # number of H1 features
        _entropy(all_life),                    # persistence entropy
    ], dtype=np.float64)


def persistence_descriptor(point_cloud: np.ndarray) -> np.ndarray:
    """Return phi_o(t) (length ``TOPO_FEATS``) for a (W, d) point cloud."""
    pts = np.asarray(point_cloud, dtype=np.float64)
    pts = pts[np.isfinite(pts).all(axis=1)] if pts.ndim == 2 else np.zeros((0, 1))
    if pts.shape[0] < 2:
        return np.zeros(TOPO_FEATS)

    if _HAVE_RIPSER:
        try:
            dgms = ripser(pts, maxdim=1)["dgms"]
            d0, d1 = dgms[0], dgms[1]
            l0 = (d0[:, 1] - d0[:, 0])
            l1 = (d1[:, 1] - d1[:, 0]) if d1.size else np.zeros(0)
            return _summarize(l0, l1)
        except Exception:
            pass  # fall through to MST

    l0 = _h0_lifetimes_mst(pts)
    return _summarize(l0, np.zeros(0))


def organ_point_cloud(window_values: np.ndarray) -> np.ndarray:
    """Build C_o(t): each of the last W hours contributes one point in the
    organ's measurement space.  ``window_values`` is (W, c_o) already
    standardized and forward-filled *within the window only* (a feature-side
    operation — the model input stream itself is never imputed)."""
    return np.asarray(window_values, dtype=np.float64)
