"""
Clinical evaluation metrics (paper Section IV-C):
discrimination (AUROC/AUPRC), timeliness (median lead time), reliability
(conformal coverage), and false-alarm rate (Eq.11).
"""
import numpy as np

try:
    from sklearn.metrics import roc_auc_score, average_precision_score
    _SK = True
except Exception:
    _SK = False


def auroc(y, p):
    y = np.asarray(y); p = np.asarray(p)
    if len(np.unique(y)) < 2:
        return float("nan")
    if _SK:
        return float(roc_auc_score(y, p))
    # rank-based fallback
    order = np.argsort(p)
    ranks = np.empty_like(order, float); ranks[order] = np.arange(1, len(p) + 1)
    pos = y > 0.5; npos = pos.sum(); nneg = (~pos).sum()
    return float((ranks[pos].sum() - npos * (npos + 1) / 2) / (npos * nneg))


def auprc(y, p):
    y = np.asarray(y); p = np.asarray(p)
    if len(np.unique(y)) < 2:
        return float("nan")
    if _SK:
        return float(average_precision_score(y, p))
    order = np.argsort(-p); y = y[order]
    tp = np.cumsum(y); fp = np.cumsum(1 - y)
    prec = tp / np.maximum(tp + fp, 1); rec = tp / max(y.sum(), 1)
    return float(np.trapz(prec, rec))


def patient_lead_time(patients, theta):
    """Median early-warning lead time (hours) between first alarm and labelled
    onset, over septic patients whose alarm fires at or before onset."""
    leads = []
    for pt in patients:
        y = np.asarray(pt["y"]); r = np.asarray(pt["risk"])
        if y.max() < 0.5:
            continue
        onset = int(np.argmax(y > 0.5))
        fired = np.where(r >= theta)[0]
        fired = fired[fired <= onset]
        if fired.size:
            leads.append(onset - fired[0])
    return float(np.median(leads)) if leads else 0.0


def false_alarm_rate(patients, theta):
    """FAR = (non-septic patients with any alarm) / (non-septic patients)."""
    nonseptic = [pt for pt in patients if np.asarray(pt["y"]).max() < 0.5]
    if not nonseptic:
        return float("nan")
    fa = sum(1 for pt in nonseptic if (np.asarray(pt["risk"]) >= theta).any())
    return fa / len(nonseptic)


def flatten_hours(patients):
    y = np.concatenate([np.asarray(p["y"]) for p in patients])
    r = np.concatenate([np.asarray(p["risk"]) for p in patients])
    return y, r
