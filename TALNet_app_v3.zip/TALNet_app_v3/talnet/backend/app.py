"""
FastAPI service for TA-LNN / TALNet sepsis early-warning.

Endpoints
---------
GET  /                      -> clinical dashboard (single-file frontend)
GET  /api/health           -> liveness + whether weights are loaded
GET  /api/meta             -> model metadata, param count, paper-vs-run metrics
GET  /api/demo             -> list of precomputed demo patients
GET  /api/demo/{pid}       -> full trajectory for one demo patient
POST /api/predict          -> run inference on an uploaded .psv file
POST /api/predict_json     -> run inference on a JSON record
GET  /api/sample.psv       -> download a sample PhysioNet .psv for testing
"""
import os
import io
import json
import tempfile

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _find(rel, default):
    """Locate a project resource robustly, regardless of the working directory
    or how the archive was extracted. Checks the package-relative path first,
    then the current working directory and common nested layouts."""
    candidates = [
        os.path.join(BASE, *rel),
        os.path.join(os.getcwd(), *rel),
        os.path.join(os.getcwd(), "talnet", *rel),
        os.path.join(BASE, "talnet", *rel),
    ]
    for c in candidates:
        if os.path.exists(c):
            return c
    return default


FRONTEND = _find(["frontend", "index.html"], os.path.join(BASE, "frontend", "index.html"))
MODELS_DIR = os.environ.get("TALNET_MODELS_DIR") or (
    os.path.dirname(_find(["models", "meta.json"], os.path.join(BASE, "models", "x"))) or os.path.join(BASE, "models"))
DEMO_DATA = _find(["data", "demo"], os.path.join(BASE, "data", "demo"))
print(f"[TA-LNN] BASE={BASE}")
print(f"[TA-LNN] frontend={'FOUND' if os.path.exists(FRONTEND) else 'MISSING'} -> {FRONTEND}")
print(f"[TA-LNN] models={'FOUND' if os.path.exists(os.path.join(MODELS_DIR, 'talnet_weights.npz')) else 'MISSING'} -> {MODELS_DIR}")

app = FastAPI(title="TA-LNN Sepsis Early-Warning API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

_model = None
_load_error = None


def model():
    """Lazy-load the trained model so the server starts even before training."""
    global _model, _load_error
    if _model is None and _load_error is None:
        try:
            from backend.inference import TALNet
            _model = TALNet(MODELS_DIR)
        except Exception as e:  # noqa
            _load_error = str(e)
    if _model is None:
        raise HTTPException(503, f"Model not available: {_load_error}")
    return _model


# --------------------------------------------------------------------------- #
@app.get("/", response_class=HTMLResponse)
def index():
    if os.path.exists(FRONTEND):
        return FileResponse(FRONTEND)
    return HTMLResponse(
        "<h1>TA-LNN API</h1><p>Frontend file not found. Expected "
        f"<code>{FRONTEND}</code>.</p><p>Start the server from inside the "
        "<code>talnet</code> folder (the one containing <code>backend/</code> and "
        "<code>frontend/</code>).</p>", status_code=200)


@app.get("/hologram", response_class=HTMLResponse)
@app.get("/anatomy_cascade.html", response_class=HTMLResponse)
def hologram():
    p = _find(["frontend", "anatomy_cascade.html"],
              os.path.join(BASE, "frontend", "anatomy_cascade.html"))
    if os.path.exists(p):
        return FileResponse(p)
    raise HTTPException(404, "Hologram frontend not found.")


@app.get("/api/health")
def health():
    ok = os.path.exists(os.path.join(MODELS_DIR, "talnet_weights.npz"))
    return {"status": "ok", "weights_present": ok}


@app.get("/api/meta")
def meta():
    path = os.path.join(MODELS_DIR, "meta.json")
    if not os.path.exists(path):
        raise HTTPException(503, "Model metadata not found — train the model first.")
    with open(path) as fh:
        m = json.load(fh)
    try:
        mdl = model()
        m["n_params_loaded"] = mdl.n_params
        c = mdl.conformal
        m["operating_point"] = {
            "theta": c.theta, "theta_conformal": c.theta_conformal,
            "coverage": c.coverage, "target_coverage": 1 - c.alpha,
            "far_target": c.far_target, "far_empirical": c.far_empirical,
            "sensitivity": c.sensitivity,
        }
    except Exception:
        pass
    return m


@app.get("/api/demo")
def demo_list():
    path = os.path.join(MODELS_DIR, "demo_patients.json")
    if not os.path.exists(path):
        raise HTTPException(503, "Demo data not found — train the model first.")
    with open(path) as fh:
        d = json.load(fh)
    summary = [{
        "id": p["id"], "n_hours": p["n_hours"], "septic": p["septic"],
        "peak_risk": p["peak_risk"], "onset_hour": p["onset_hour"],
        "first_alarm_hour": p["first_alarm_hour"], "lead_time_hours": p["lead_time_hours"],
    } for p in d["patients"]]
    return {"threshold": d["threshold"], "organs": d["organs"],
            "organ_labels": d["organ_labels"], "patients": summary}


@app.get("/api/demo/{pid}")
def demo_detail(pid: str):
    path = os.path.join(MODELS_DIR, "demo_patients.json")
    with open(path) as fh:
        d = json.load(fh)
    for p in d["patients"]:
        if p["id"] == pid:
            p = dict(p)
            p["organs"] = d["organs"]; p["organ_labels"] = d["organ_labels"]
            p["threshold"] = d["threshold"]
            return p
    raise HTTPException(404, f"Patient {pid} not found")


@app.post("/api/predict")
async def predict(file: UploadFile = File(...)):
    raw = await file.read()
    with tempfile.NamedTemporaryFile("wb", suffix=".psv", delete=False) as tf:
        tf.write(raw); tmp = tf.name
    try:
        out = model().predict_psv(tmp)
    finally:
        os.unlink(tmp)
    out["source"] = file.filename
    return JSONResponse(out)


class Record(BaseModel):
    columns: list[str] | None = None
    data: list[list] | None = None


@app.post("/api/predict_json")
def predict_json(rec: Record):
    if not rec.columns or not rec.data:
        raise HTTPException(400, "Provide 'columns' and 'data'.")
    return JSONResponse(model().predict_json({"columns": rec.columns, "data": rec.data}))


@app.get("/api/sample.psv", response_class=PlainTextResponse)
def sample_psv():
    if os.path.isdir(DEMO_DATA):
        for f in sorted(os.listdir(DEMO_DATA)):
            if f.endswith(".psv"):
                return FileResponse(os.path.join(DEMO_DATA, f), media_type="text/plain",
                                    filename=f)
    raise HTTPException(404, "No sample available.")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.app:app", host="0.0.0.0", port=8000, reload=False)
