"""
Train, calibrate, and evaluate the TA-LNN on the PhysioNet/CinC 2019 corpus.

Pipeline (paper Table 1):
  1. Fit standardization stats on observed values only (train split).
  2. Build per-organ input streams + cached persistent-homology descriptors.
  3. Train the coupled liquid network (Adam, autograd) with a masked BCE risk
     loss + weak organ-cascade supervision.
  4. Split-conformal calibration of the alarm threshold on a held-out split.
  5. Evaluate discrimination / lead time / FAR / coverage and export artifacts
     (weights, scaler, conformal, metrics) + demo-patient outputs for the app.

Usage:
  python -m backend.train --data /path/to/training_setA \
      --n-train 1200 --n-cal 500 --n-test 900 --epochs 22
"""
import os, sys, json, time, argparse, random, pickle
import numpy as np
import autograd.numpy as anp
from autograd import grad
from autograd.misc import flatten
from multiprocessing import Pool

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend.config import (ORGANS, K_ORGANS, ORGAN_CHANNELS, TOPO_FEATS,
                            CONFORMAL_ALPHA, CASCADE_WEIGHT, ORGAN_LABELS)
from backend.data import Scaler, read_psv, build_patient, list_psv
from backend.model import init_params, forward, save_params, count_params
from backend.conformal import ConformalAlarm
from backend import metrics as M

TMAX = 64
_SCALER = None


# --------------------------------------------------------------------------- #
# Feature building (parallel)
# --------------------------------------------------------------------------- #
def _feat_worker(path):
    vals, demog, label = read_psv(path)
    if vals.shape[0] < 4:
        return None
    feats = build_patient(vals, demog, label, _SCALER)
    feats["path"] = path
    feats["id"] = os.path.splitext(os.path.basename(path))[0]
    return feats


def build_split(files, scaler, procs=2):
    global _SCALER
    _SCALER = scaler
    out = []
    with Pool(procs, initializer=_init_pool, initargs=(scaler,)) as pool:
        for i, f in enumerate(pool.imap(_feat_worker, files, chunksize=8)):
            if f is not None:
                out.append(f)
            if (i + 1) % 200 == 0:
                print(f"    ...features {i+1}/{len(files)}", flush=True)
    return out


def _init_pool(scaler):
    global _SCALER
    _SCALER = scaler


# --------------------------------------------------------------------------- #
# Pack a split into padded batched arrays (for training)
# --------------------------------------------------------------------------- #
def pack_padded(feats_list, tmax=TMAX):
    N = len(feats_list)
    Us = {o: np.zeros((N, tmax, 3 * len(ORGAN_CHANNELS[o]))) for o in ORGANS}
    Ps = {o: np.zeros((N, tmax, TOPO_FEATS)) for o in ORGANS}
    demog = np.zeros((N, feats_list[0]["demog"].shape[0]))
    y = np.zeros((N, tmax)); ot = np.zeros((N, tmax, K_ORGANS)); seqm = np.zeros((N, tmax))
    for i, ft in enumerate(feats_list):
        T = ft["T"]; yy = ft["y"]
        # keep onset region for septic patients, else last tmax hours
        end = T
        if yy is not None and yy.max() > 0.5:
            onset = int(np.argmax(yy > 0.5)); end = min(T, onset + 6)
        start = max(0, end - tmax); L = end - start
        for o in ORGANS:
            Us[o][i, :L] = ft["U"][o][start:end]
            Ps[o][i, :L] = ft["PHI"][o][start:end]
        demog[i] = ft["demog"]
        if yy is not None:
            y[i, :L] = yy[start:end]
        ot[i, :L] = ft["organ_target"][start:end]
        seqm[i, :L] = 1.0
    return {"U": Us, "PHI": Ps, "demog": demog, "y": y, "organ_target": ot, "seqmask": seqm}


# --------------------------------------------------------------------------- #
# Loss
# --------------------------------------------------------------------------- #
def make_loss(batch, pos_weight, l2=1e-5):
    y = batch["y"]; seqm = batch["seqmask"]; ot = batch["organ_target"]
    inp = {"U": batch["U"], "PHI": batch["PHI"], "demog": batch["demog"], "dt": 1.0}

    def loss(params):
        risk, cascade, _ = forward(params, inp)
        eps = 1e-6
        r = anp.clip(risk, eps, 1 - eps)
        w = 1.0 + (pos_weight - 1.0) * y                       # up-weight positives
        bce = -(pos_weight * y * anp.log(r) + (1 - y) * anp.log(1 - r))
        bce = anp.sum(bce * seqm) / (anp.sum(seqm) + 1e-9)
        # weak cascade supervision (cross-entropy to organ-derangement target)
        c = anp.clip(cascade, eps, 1.0)
        casc = -anp.sum(ot * anp.log(c), axis=2)
        casc = anp.sum(casc * seqm) / (anp.sum(seqm) + 1e-9)
        reg = l2 * sum(anp.sum(v * v) for k, v in params.items() if k.startswith("W"))
        return bce + CASCADE_WEIGHT * casc + reg
    return loss


# --------------------------------------------------------------------------- #
# Adam optimiser (autograd)
# --------------------------------------------------------------------------- #
def adam_train(params, feats_train, epochs, batch_size, pos_weight,
               lr=3e-3, seed=0, ckpt=None, max_seconds=None):
    """Resumable Adam. Saves an epoch-level checkpoint to ``ckpt`` and stops
    early (returning done=False) if ``max_seconds`` is exceeded, so training can
    span several short invocations."""
    rng = np.random.RandomState(seed)
    flat0, unflatten = flatten(params)
    x = np.array(flat0, dtype=np.float64)
    m = np.zeros_like(x); v = np.zeros_like(x)
    b1, b2, eps = 0.9, 0.999, 1e-8
    start_ep = 0; step = 0
    if ckpt and os.path.exists(ckpt):
        z = np.load(ckpt)
        if z["x"].shape == x.shape:
            x, m, v = z["x"], z["m"], z["v"]; step = int(z["step"]); start_ep = int(z["epoch"])
            print(f"  [resume] from epoch {start_ep}", flush=True)
        else:
            print("  [ckpt] shape mismatch — ignoring stale checkpoint, training fresh", flush=True)
    N = len(feats_train); idx = np.arange(N)
    t0 = time.time()
    for ep in range(start_ep, epochs):
        rng.seed(seed + ep); rng.shuffle(idx); ep_loss = 0.0; nb = 0
        for s in range(0, N, batch_size):
            sub = [feats_train[j] for j in idx[s:s + batch_size]]
            batch = pack_padded(sub)
            loss_fn = make_loss(batch, pos_weight)
            g = grad(lambda flt: loss_fn(unflatten(flt)))(x)
            l = loss_fn(unflatten(x))
            step += 1
            m = b1 * m + (1 - b1) * g
            v = b2 * v + (1 - b2) * (g * g)
            mh = m / (1 - b1 ** step); vh = v / (1 - b2 ** step)
            x = x - lr * mh / (np.sqrt(vh) + eps)
            ep_loss += float(l); nb += 1
        print(f"  epoch {ep+1:2d}/{epochs}  loss={ep_loss/max(nb,1):.4f}  ({time.time()-t0:.0f}s)", flush=True)
        if ckpt:
            np.savez(ckpt, x=x, m=m, v=v, step=step, epoch=ep + 1)
        if max_seconds and (time.time() - t0) > max_seconds and ep + 1 < epochs:
            print(f"  [pause] time budget hit at epoch {ep+1}/{epochs}", flush=True)
            return unflatten(x), False
    return unflatten(x), True


# --------------------------------------------------------------------------- #
# Per-patient inference (full length) for eval / calibration / export
# --------------------------------------------------------------------------- #
def infer_patient(params, ft):
    U = {o: ft["U"][o][None, ...] for o in ORGANS}
    PHI = {o: ft["PHI"][o][None, ...] for o in ORGANS}
    demog = ft["demog"][None, :]
    risk, cascade, tau = forward(params, {"U": U, "PHI": PHI, "demog": demog, "dt": 1.0})
    return np.asarray(risk)[0], np.asarray(cascade)[0], np.asarray(tau)[0]


def collect_predictions(params, feats):
    pts = []
    for ft in feats:
        r, c, tau = infer_patient(params, ft)
        pts.append({"id": ft["id"], "y": (ft["y"] if ft["y"] is not None else np.zeros(len(r))),
                    "risk": r, "cascade": c, "tau": tau})
    return pts


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", default=os.path.join(os.path.dirname(os.path.dirname(__file__)), "models"))
    ap.add_argument("--n-train", type=int, default=1200)
    ap.add_argument("--n-cal", type=int, default=500)
    ap.add_argument("--n-test", type=int, default=900)
    ap.add_argument("--epochs", type=int, default=22)
    ap.add_argument("--batch-size", type=int, default=64)
    ap.add_argument("--procs", type=int, default=2)
    ap.add_argument("--cache", default=None, help="feature cache path (default models/_feature_cache.pkl)")
    ap.add_argument("--cache-only", action="store_true", help="build+cache features then exit")
    ap.add_argument("--max-seconds", type=float, default=None, help="pause training after N seconds (resumable)")
    ap.add_argument("--target-far", type=float, default=0.10, help="target patient-level false-alarm rate for the operating threshold")
    ap.add_argument("--pos-weight", type=float, default=None, help="override positive class weight in BCE")
    ap.add_argument("--lr", type=float, default=3e-3)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    t0 = time.time()

    cache = args.cache or os.path.join(args.out, "_feature_cache.pkl")
    if os.path.exists(cache):
        print(f"[cache] loading features from {cache}", flush=True)
        with open(cache, "rb") as fh:
            blob = pickle.load(fh)
        scaler = Scaler.from_dict(blob["scaler"]); f_tr = blob["train"]; f_ca = blob["cal"]; f_te = blob["test"]
        print(f"[cache] train={len(f_tr)} cal={len(f_ca)} test={len(f_te)}", flush=True)
    else:
        files = list_psv(args.data)
        random.seed(args.seed); random.shuffle(files)
        n = args.n_train + args.n_cal + args.n_test
        files = files[:min(n, len(files))]
        tr = files[:args.n_train]
        ca = files[args.n_train:args.n_train + args.n_cal]
        te = files[args.n_train + args.n_cal:]
        print(f"[data] train={len(tr)} cal={len(ca)} test={len(te)}", flush=True)

        print("[1/6] fitting scaler (observed values only)...", flush=True)
        scaler = Scaler.fit(tr)

        print("[2/6] building features (topology cache)...", flush=True)
        tf0 = time.time()
        f_tr = build_split(tr, scaler, args.procs); print(f"    train feats={len(f_tr)}", flush=True)
        f_ca = build_split(ca, scaler, args.procs); print(f"    cal   feats={len(f_ca)}", flush=True)
        f_te = build_split(te, scaler, args.procs); print(f"    test  feats={len(f_te)}", flush=True)
        print(f"    feature build {time.time()-tf0:.1f}s -> caching", flush=True)
        with open(cache, "wb") as fh:
            pickle.dump({"scaler": scaler.to_dict(), "train": f_tr, "cal": f_ca, "test": f_te}, fh)
        if args.cache_only:
            print("[cache] features cached; exiting (--cache-only)", flush=True); return

    # class weight from train hours
    yy = np.concatenate([ft["y"] for ft in f_tr if ft["y"] is not None])
    pos = max(yy.sum(), 1); neg = max((yy == 0).sum(), 1)
    pos_weight = float(args.pos_weight if args.pos_weight else min(neg / pos, 25.0))
    print(f"[3/6] training  (pos_weight={pos_weight:.1f}, params to init)...", flush=True)

    params = init_params(args.seed)
    print(f"    trainable parameters = {count_params(params):,}", flush=True)
    ckpt = os.path.join(args.out, "_train_ckpt.npz")
    params, done = adam_train(params, f_tr, args.epochs, args.batch_size, pos_weight,
                              lr=args.lr, seed=args.seed, ckpt=ckpt, max_seconds=args.max_seconds)
    if not done:
        print("[paused] training not finished — re-run the same command to continue.", flush=True)
        return

    print("[4/6] conformal calibration...", flush=True)
    cal_pts = collect_predictions(params, f_ca)
    cal_y = np.concatenate([p["y"] for p in cal_pts])
    cal_r = np.concatenate([p["risk"] for p in cal_pts])
    conf = ConformalAlarm.calibrate(cal_r, cal_y, alpha=CONFORMAL_ALPHA,
                                    patients=cal_pts, target_far=args.target_far)
    print(f"    theta_op={conf.theta:.3f}  conformal_cov={conf.coverage:.3f}  "
          f"FAR~{conf.far_empirical}  sens={conf.sensitivity}", flush=True)

    print("[5/6] evaluating on held-out test split...", flush=True)
    test_pts = collect_predictions(params, f_te)
    ty, tr_ = M.flatten_hours(test_pts)
    results = {
        "AUROC": M.auroc(ty, tr_), "AUPRC": M.auprc(ty, tr_),
        "lead_time_h": M.patient_lead_time(test_pts, conf.theta),
        "FAR": M.false_alarm_rate(test_pts, conf.theta),
        "coverage": conf.coverage, "params": count_params(params),
        "n_test_patients": len(test_pts),
        "theta_op": conf.theta, "theta_conformal": conf.theta_conformal,
        "far_target": conf.far_target,
    }
    print("    " + json.dumps({k: (round(v, 4) if isinstance(v, float) else v)
                               for k, v in results.items()}), flush=True)

    print("[6/6] saving artifacts + demo export...", flush=True)
    save_params(params, os.path.join(args.out, "talnet_weights.npz"))
    with open(os.path.join(args.out, "scaler.json"), "w") as fh:
        json.dump(scaler.to_dict(), fh)
    conf.save(os.path.join(args.out, "conformal.json"))

    # class distribution (paper Figs 2-3)
    class_dist = {"positive_hours": int(pos), "negative_hours": int(neg),
                  "positive_pct": float(100 * pos / (pos + neg))}

    meta = {
        "version": "1.0.0", "trained_on": "PhysioNet/CinC 2019 Set A",
        "split": {"train": len(f_tr), "cal": len(f_ca), "test": len(f_te)},
        "tmax": TMAX, "epochs": args.epochs, "results": results,
        "class_distribution": class_dist,
        "organs": ORGANS, "organ_labels": [ORGAN_LABELS[o] for o in ORGANS],
        "paper_reference": {  # values reported in the paper for comparison
            "TA-LNN": {"AUROC": 0.934, "AUPRC": 0.648, "lead_time_h": 7.4, "FAR": 0.091, "params": 790000},
            "baselines": {
                "LSTM": {"AUROC": 0.864, "AUPRC": 0.512, "lead_time_h": 3.8, "FAR": 0.193},
                "GRU": {"AUROC": 0.876, "AUPRC": 0.531, "lead_time_h": 4.2, "FAR": 0.178},
                "Neural CDE": {"AUROC": 0.901, "AUPRC": 0.584, "lead_time_h": 5.6, "FAR": 0.142},
            },
            "ablation": {
                "w/o topology": {"AUROC": 0.909, "coverage": 0.889},
                "w/o per-organ": {"AUROC": 0.916, "coverage": 0.893},
                "w/o coupling": {"AUROC": 0.921, "coverage": 0.897},
                "Full TA-LNN": {"AUROC": 0.934, "coverage": 0.902},
            },
        },
        "elapsed_sec": round(time.time() - t0, 1),
    }
    with open(os.path.join(args.out, "meta.json"), "w") as fh:
        json.dump(meta, fh, indent=2)

    # ---- export demo patients for the dashboard (mix of septic + non) ------
    export_demo(test_pts, f_te, conf, args.out)
    print(f"[done] total {time.time()-t0:.1f}s", flush=True)


def export_demo(test_pts, feats, conf, out, n=40):
    septic = [i for i, p in enumerate(test_pts) if p["y"].max() > 0.5]
    nonsep = [i for i, p in enumerate(test_pts) if p["y"].max() < 0.5]
    random.seed(1)
    pick = (septic[:20] + random.sample(nonsep, min(20, len(nonsep))))[:n]
    demo = []
    for i in pick:
        p = test_pts[i]; r = p["risk"]; c = p["cascade"]; y = p["y"]; tau = p["tau"]
        alarm = (r >= conf.theta)
        onset = int(np.argmax(y > 0.5)) if y.max() > 0.5 else None
        fa = int(np.argmax(alarm)) if alarm.any() else None
        lead = (onset - fa) if (onset is not None and fa is not None and fa <= onset) else None
        demo.append({
            "id": p["id"], "n_hours": int(len(r)),
            "septic": bool(y.max() > 0.5),
            "risk": [round(float(x), 4) for x in r],
            "alarm": [bool(x) for x in alarm],
            "label": [int(v) for v in y],
            "cascade": [[round(float(c[t, k]), 4) for k in range(K_ORGANS)] for t in range(len(r))],
            "tau": [[round(float(tau[t, k]), 3) for k in range(K_ORGANS)] for t in range(len(r))],
            "onset_hour": (onset + 1 if onset is not None else None),
            "first_alarm_hour": (fa + 1 if fa is not None else None),
            "lead_time_hours": lead,
            "peak_risk": round(float(r.max()), 4),
        })
    with open(os.path.join(out, "demo_patients.json"), "w") as fh:
        json.dump({"threshold": conf.theta, "organs": ORGANS,
                   "organ_labels": [ORGAN_LABELS[o] for o in ORGANS], "patients": demo}, fh)
    print(f"    exported {len(demo)} demo patients", flush=True)


if __name__ == "__main__":
    main()
